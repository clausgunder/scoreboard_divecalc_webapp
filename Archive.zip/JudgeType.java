/* Decompiler 5ms, total 155ms, lines 8 */
package divecalc.competition;

public enum JudgeType {
   SYNCRO,
   A,
   B;
}
