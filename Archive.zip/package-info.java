/* Decompiler 2ms, total 172ms, lines 5 */
package divecalc.competition;

interface package-info {
}
