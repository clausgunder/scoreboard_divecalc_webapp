/* Decompiler 3ms, total 184ms, lines 11 */
package javax.persistence;

public class NoResultException extends PersistenceException {
   public NoResultException() {
   }

   public NoResultException(String msg) {
      super(msg);
   }
}
