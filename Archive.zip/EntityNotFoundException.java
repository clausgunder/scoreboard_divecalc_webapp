/* Decompiler 2ms, total 163ms, lines 11 */
package javax.persistence;

public class EntityNotFoundException extends PersistenceException {
   public EntityNotFoundException() {
   }

   public EntityNotFoundException(String msg) {
      super(msg);
   }
}
