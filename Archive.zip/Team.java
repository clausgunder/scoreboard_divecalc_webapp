/* Decompiler 1ms, total 156ms, lines 8 */
package divecalc.competition;

public interface Team {
   String getName();

   String getShortName();
}
