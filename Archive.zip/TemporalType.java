/* Decompiler 3ms, total 173ms, lines 8 */
package javax.persistence;

public enum TemporalType {
   DATE,
   TIME,
   TIMESTAMP;
}
