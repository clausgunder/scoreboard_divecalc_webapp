/* Decompiler 2ms, total 168ms, lines 11 */
package javax.persistence;

public class NonUniqueResultException extends PersistenceException {
   public NonUniqueResultException() {
   }

   public NonUniqueResultException(String msg) {
      super(msg);
   }
}
