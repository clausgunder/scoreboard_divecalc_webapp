/* Decompiler 1ms, total 427ms, lines 6 */
package divecalc.competition;

public interface Ruleset2 extends Ruleset {
   String getSeriesName(Event var1);
}
