/* Decompiler 0ms, total 188ms, lines 16 */
package divecalc.competition;

public interface SyncroDive extends Dive {
   DiveNumber getDive2();

   Height getHeight2();

   Award getMaxAward2();

   Award getPenalty2();

   Award getSyncroMaxAward();

   Award getSyncroPenalty();
}
